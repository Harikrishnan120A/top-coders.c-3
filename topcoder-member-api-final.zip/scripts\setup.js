#!/usr/bin/env node

/**
 * Development setup script
 * This script helps set up the development environment
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Setting up Topcoder Member API development environment...\n');

async function setupEnvironment() {
  try {
    // Check if .env exists
    if (!fs.existsSync('.env')) {
      console.log('📄 Creating .env file from template...');
      if (fs.existsSync('.env.example')) {
        fs.copyFileSync('.env.example', '.env');
        console.log('✅ .env file created. Please update DATABASE_URL if needed.\n');
      } else {
        console.log('❌ .env.example not found. Please create .env manually.\n');
      }
    } else {
      console.log('✅ .env file already exists.\n');
    }

    // Check if Docker is available
    try {
      execSync('docker --version', { stdio: 'pipe' });
      console.log('🐳 Docker is available');
      
      try {
        execSync('docker-compose --version', { stdio: 'pipe' });
        console.log('🐳 Docker Compose is available');
        console.log('📦 To start PostgreSQL with Docker: npm run docker:start\n');
      } catch (error) {
        console.log('⚠️ Docker Compose not found. Please install Docker Compose.\n');
      }
    } catch (error) {
      console.log('⚠️ Docker not found. Please install Docker or set up PostgreSQL manually.\n');
    }

    // Install dependencies
    console.log('📦 Installing dependencies...');
    execSync('npm install', { stdio: 'inherit' });
    console.log('✅ Dependencies installed.\n');

    // Generate Prisma client
    console.log('🔧 Generating Prisma client...');
    execSync('npm run prisma:generate', { stdio: 'inherit' });
    console.log('✅ Prisma client generated.\n');

    console.log('🎉 Setup complete!\n');
    console.log('Next steps:');
    console.log('1. Start PostgreSQL (docker-compose up -d postgres OR start manually)');
    console.log('2. Run migrations: npm run prisma:migrate');
    console.log('3. Seed database: npm run prisma:seed');
    console.log('4. Start development server: npm run dev');
    console.log('\n📖 For detailed instructions, see docs/development-setup.md');

  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    process.exit(1);
  }
}

// Add package.json scripts if not present
function addPackageScripts() {
  const packageJsonPath = path.join(__dirname, '..', 'package.json');
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));

  const newScripts = {
    'docker:start': 'docker-compose up -d',
    'docker:stop': 'docker-compose down',
    'docker:logs': 'docker-compose logs -f',
    'setup': 'node scripts/setup.js'
  };

  let updated = false;
  for (const [script, command] of Object.entries(newScripts)) {
    if (!packageJson.scripts[script]) {
      packageJson.scripts[script] = command;
      updated = true;
    }
  }

  if (updated) {
    fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));
    console.log('✅ Added helpful npm scripts to package.json\n');
  }
}

if (require.main === module) {
  addPackageScripts();
  setupEnvironment();
}
