/**
 * Validation utilities for API requests
 */

export interface ValidationError {
  field: string;
  message: string;
  value?: unknown;
}

/**
 * Validate required fields
 */
export const validateRequired = (
  data: Record<string, unknown>,
  requiredFields: string[]
): ValidationError[] => {
  const errors: ValidationError[] = [];

  for (const field of requiredFields) {
    const value = data[field];
    if (value === undefined || value === null || value === '') {
      errors.push({
        field,
        message: `${field} is required`,
        value
      });
    }
  }

  return errors;
};

/**
 * Validate email format
 */
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate handle format (alphanumeric, underscore, dash)
 */
export const validateHandle = (handle: string): boolean => {
  const handleRegex = /^[a-zA-Z0-9_-]+$/;
  return handleRegex.test(handle) && handle.length >= 3 && handle.length <= 50;
};

/**
 * Validate positive integer
 */
export const validatePositiveInteger = (value: unknown): boolean => {
  const num = parseInt(String(value));
  return !isNaN(num) && num > 0;
};

/**
 * Validate array of strings
 */
export const validateStringArray = (value: unknown): boolean => {
  return Array.isArray(value) && value.every(item => typeof item === 'string');
};

/**
 * Sanitize query parameters
 */
export const sanitizeQuery = (query: Record<string, unknown>): Record<string, unknown> => {
  const sanitized: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null && value !== '') {
      // Convert string arrays from comma-separated values
      if (typeof value === 'string' && value.includes(',')) {
        sanitized[key] = value.split(',').map(item => item.trim());
      } else {
        sanitized[key] = value;
      }
    }
  }

  return sanitized;
};
