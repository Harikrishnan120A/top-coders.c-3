import { PrismaClient } from '@prisma/client';
import { faker } from '@faker-js/faker';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  console.log('🌱 Starting database seeding...');

  try {
    // Clear existing data in reverse order of dependencies
    console.log('🧹 Cleaning existing data...');
    await prisma.memberStatistic.deleteMany();
    await prisma.memberAchievement.deleteMany();
    await prisma.memberSkill.deleteMany();
    await prisma.memberSubTrack.deleteMany();
    await prisma.memberTrack.deleteMany();
    await prisma.member.deleteMany();
    await prisma.achievement.deleteMany();
    await prisma.skill.deleteMany();
    await prisma.subTrack.deleteMany();
    await prisma.track.deleteMany();

    // Create tracks
    console.log('📊 Creating tracks...');
    const trackData = [
      { name: 'Development', description: 'Software development track' },
      { name: 'Design', description: 'Design and UX track' },
      { name: 'Data Science', description: 'Data science and analytics track' },
      { name: 'QA', description: 'Quality assurance track' },
      { name: 'Copilot', description: 'Project management track' }
    ];

    const createdTracks = [];
    for (const track of trackData) {
      const created = await prisma.track.create({
        data: {
          name: track.name,
          description: track.description,
          isActive: true
        }
      });
      createdTracks.push(created);
    }

    // Create sub-tracks
    console.log('🔹 Creating sub-tracks...');
    const createdSubTracks = [];
    for (const track of createdTracks) {
      const subTrackNames = track.name === 'Development' 
        ? ['Web Development', 'Mobile Development', 'Backend Development']
        : track.name === 'Design' 
        ? ['UI Design', 'UX Design', 'Graphic Design']
        : [`${track.name} Category 1`, `${track.name} Category 2`];

      for (const subTrackName of subTrackNames) {
        const subTrack = await prisma.subTrack.create({
          data: {
            trackId: track.id,
            name: subTrackName,
            description: `${subTrackName} in ${track.name}`,
            isActive: true
          }
        });
        createdSubTracks.push(subTrack);
      }
    }

    // Create skills
    console.log('🛠️ Creating skills...');
    const skillNames = [
      'JavaScript', 'TypeScript', 'Python', 'Java', 'React', 'Angular', 'Vue.js',
      'Node.js', 'Express.js', 'MongoDB', 'PostgreSQL', 'MySQL', 'Redis',
      'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP', 'HTML/CSS', 'Figma'
    ];

    const createdSkills = [];
    for (const skillName of skillNames) {
      const created = await prisma.skill.create({
        data: {
          name: skillName,
          description: `${skillName} programming skill`,
          category: faker.helpers.arrayElement(['Frontend', 'Backend', 'Database', 'DevOps', 'Design']),
          isActive: true
        }
      });
      createdSkills.push(created);
    }

    // Create achievements
    console.log('🏆 Creating achievements...');
    const achievementData = [
      { name: 'First Win', description: 'Won your first challenge', type: 'BADGE' },
      { name: 'Top Performer', description: 'Finished in top 3', type: 'AWARD' },
      { name: 'Certified Developer', description: 'Completed certification', type: 'CERTIFICATION' },
      { name: 'Community Leader', description: 'Active community member', type: 'BADGE' },
      { name: 'Innovation Award', description: 'Most innovative solution', type: 'AWARD' }
    ];

    const createdAchievements = [];
    for (const achievement of achievementData) {
      const created = await prisma.achievement.create({
        data: {
          name: achievement.name,
          description: achievement.description,
          type: achievement.type,
          category: faker.helpers.arrayElement(['Competition', 'Community', 'Learning']),
          isActive: true
        }
      });
      createdAchievements.push(created);
    }

    // Create members
    console.log('👥 Creating members...');
    const createdMembers = [];
    for (let i = 0; i < 50; i++) {
      const firstName = faker.person.firstName();
      const lastName = faker.person.lastName();
      const handle = `${firstName.toLowerCase()}${lastName.toLowerCase()}${faker.number.int({ min: 1, max: 999 })}`;
      const userId = faker.number.int({ min: 100000, max: 999999 });
      
      const member = await prisma.member.create({
        data: {
          userId,
          handle,
          firstName,
          lastName,
          email: faker.internet.email({ firstName, lastName }),
          description: faker.lorem.paragraph(),
          country: faker.location.country(),
          status: faker.helpers.arrayElement(['ACTIVE', 'INACTIVE']),
          memberSince: faker.date.past({ years: 3 }),
          lastLoginAt: faker.date.recent({ days: 30 }),
          isEmailVerified: faker.datatype.boolean({ probability: 0.8 }),
          photoURL: faker.image.avatar()
        }
      });
      createdMembers.push(member);
    }

    // Create member-track relationships
    console.log('🔗 Creating member-track relationships...');
    for (const member of createdMembers) {
      // Each member belongs to 1-3 tracks
      const memberTracks = faker.helpers.arrayElements(createdTracks, { min: 1, max: 3 });
      for (const track of memberTracks) {
        await prisma.memberTrack.create({
          data: {
            memberId: member.id,
            trackId: track.id
          }
        });
      }
    }

    // Create member-subtrack relationships
    console.log('🔗 Creating member-subtrack relationships...');
    for (const member of createdMembers) {
      // Each member has ratings in 1-5 sub-tracks
      const memberSubTracks = faker.helpers.arrayElements(createdSubTracks, { min: 1, max: 5 });
      for (const subTrack of memberSubTracks) {
        await prisma.memberSubTrack.create({
          data: {
            memberId: member.id,
            subTrackId: subTrack.id,
            rating: faker.number.int({ min: 800, max: 2500 }),
            reliability: faker.number.int({ min: 0, max: 100 })
          }
        });
      }
    }

    // Create member skills
    console.log('🎯 Creating member skills...');
    for (const member of createdMembers) {
      // Each member gets 3-7 random skills
      const memberSkillCount = faker.number.int({ min: 3, max: 7 });
      const selectedSkills = faker.helpers.arrayElements(createdSkills, memberSkillCount);
      
      for (const skill of selectedSkills) {
        await prisma.memberSkill.create({
          data: {
            memberId: member.id,
            skillId: skill.id,
            score: faker.number.int({ min: 1, max: 5 }),
            achievedAt: faker.date.between({ 
              from: member.memberSince || new Date(), 
              to: new Date() 
            })
          }
        });
      }
    }

    // Create member achievements
    console.log('🏅 Creating member achievements...');
    for (const member of createdMembers) {
      // Some members have achievements
      if (faker.datatype.boolean({ probability: 0.6 })) {
        const memberAchievements = faker.helpers.arrayElements(createdAchievements, { min: 1, max: 3 });
        for (const achievement of memberAchievements) {
          await prisma.memberAchievement.create({
            data: {
              memberId: member.id,
              achievementId: achievement.id,
              achievedAt: faker.date.between({ 
                from: member.memberSince || new Date(), 
                to: new Date() 
              })
            }
          });
        }
      }
    }

    // Create member statistics
    console.log('📈 Creating member statistics...');
    const statTypes = ['RATING', 'WINS', 'CHALLENGES', 'SUBMISSIONS', 'EARNINGS'];
    for (const member of createdMembers) {
      for (const statType of statTypes) {
        // All-time stats
        await prisma.memberStatistic.create({
          data: {
            memberId: member.id,
            type: statType,
            value: statType === 'RATING' 
              ? faker.number.int({ min: 800, max: 2500 })
              : statType === 'EARNINGS'
              ? faker.number.float({ min: 0, max: 50000, fractionDigits: 2 })
              : faker.number.int({ min: 0, max: 100 }),
            period: 'ALL_TIME'
          }
        });

        // Track-specific stats for rating
        if (statType === 'RATING') {
          for (const track of createdTracks) {
            if (faker.datatype.boolean({ probability: 0.7 })) {
              await prisma.memberStatistic.create({
                data: {
                  memberId: member.id,
                  type: statType,
                  value: faker.number.int({ min: 800, max: 2500 }),
                  trackId: track.id,
                  period: 'ALL_TIME'
                }
              });
            }
          }
        }
      }
    }

    console.log('✅ Database seeding completed successfully!');
    console.log(`📊 Created:`);
    console.log(`   - ${createdTracks.length} tracks`);
    console.log(`   - ${createdSubTracks.length} sub-tracks`);
    console.log(`   - ${createdSkills.length} skills`);
    console.log(`   - ${createdAchievements.length} achievements`);
    console.log(`   - ${createdMembers.length} members`);
    console.log(`   - Plus member relationships, skills, achievements, and statistics`);

  } catch (error) {
    console.error('❌ Error during seeding:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
