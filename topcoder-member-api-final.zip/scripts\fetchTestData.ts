import fs from 'fs';
import path from 'path';
import https from 'https';

/**
 * Script to fetch test data from the live Topcoder API
 * This will help us create realistic test data for local development
 */

const TOPCODER_API_BASE = 'https://api.topcoder-dev.com/v5';
const DATA_DIR = path.join(__dirname, '..', 'data');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface FetchOptions {
  url: string;
  filename: string;
  params?: Record<string, string>;
}

function fetchData(options: FetchOptions): Promise<any> {
  return new Promise((resolve, reject) => {
    const url = new URL(options.url);
    
    if (options.params) {
      Object.entries(options.params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    console.log(`Fetching data from: ${url.toString()}`);

    const req = https.get(url.toString(), (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const jsonData = JSON.parse(data);
          const filePath = path.join(DATA_DIR, options.filename);
          
          fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2));
          console.log(`✅ Saved data to: ${filePath}`);
          
          resolve(jsonData);
        } catch (error) {
          console.error(`❌ Error parsing JSON for ${options.filename}:`, error);
          reject(error);
        }
      });
    });

    req.on('error', (error) => {
      console.error(`❌ Error fetching ${options.filename}:`, error);
      reject(error);
    });

    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
  });
}

async function fetchTestData() {
  console.log('🚀 Starting to fetch test data from Topcoder API...');

  try {
    // Fetch sample members data
    await fetchData({
      url: `${TOPCODER_API_BASE}/members`,
      filename: 'members_sample.json',
      params: {
        limit: '50',
        offset: '0'
      }
    });

    // Fetch members with specific handles for testing
    const testHandles = ['dok', 'sima_zh', 'poundinc_tc', 'abedal', 'mess'];
    
    for (const handle of testHandles) {
      try {
        await fetchData({
          url: `${TOPCODER_API_BASE}/members/${handle}`,
          filename: `member_${handle}.json`
        });
        
        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        console.log(`⚠️  Could not fetch member ${handle}, continuing...`);
      }
    }

    // Fetch statistics data
    await fetchData({
      url: `${TOPCODER_API_BASE}/members/statistics`,
      filename: 'statistics_sample.json'
    });

    console.log('✅ Test data fetching completed!');
    console.log(`📁 Data saved in: ${DATA_DIR}`);

  } catch (error) {
    console.error('❌ Error during data fetching:', error);
    process.exit(1);
  }
}

// Run the script
if (require.main === module) {
  fetchTestData();
}

export { fetchTestData };
