import { Router } from 'express';
import { SearchController } from '../controllers/SearchController';
import { StatisticsController } from '../controllers/StatisticsController';
import { paginationMiddleware } from '../middlewares/pagination';
import { asyncHandler } from '../middlewares/errorHandler';

const router = Router();

// Member search routes
router.get('/members', paginationMiddleware, asyncHandler(SearchController.searchMembers));
router.get('/members/:handle', asyncHandler(SearchController.getMemberByHandle));

// Member statistics routes
router.get('/members/statistics', asyncHandler(StatisticsController.getMemberStatistics));
router.get('/members/statistics/skills', asyncHandler(StatisticsController.getSkillsStatistics));
router.get('/members/statistics/tracks', asyncHandler(StatisticsController.getTrackStatistics));
router.get('/members/statistics/countries', asyncHandler(StatisticsController.getCountryStatistics));
router.get('/members/statistics/performance', asyncHandler(StatisticsController.getPerformanceStatistics));

export default router;
