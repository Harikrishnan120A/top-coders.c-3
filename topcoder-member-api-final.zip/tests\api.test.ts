import request from 'supertest';
import { app } from '../src/index';

describe('Member API Health Check', () => {
  it('should return health status', async () => {
    const response = await request(app)
      .get('/health')
      .expect(200);

    expect(response.body).toHaveProperty('status', 'OK');
    expect(response.body).toHaveProperty('message', 'Member API is running');
    expect(response.body).toHaveProperty('timestamp');
  });

  it('should return API information at root', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    expect(response.body).toHaveProperty('message', 'Topcoder Member API v5');
    expect(response.body).toHaveProperty('endpoints');
  });

  it('should return 404 for unknown routes', async () => {
    const response = await request(app)
      .get('/unknown-route')
      .expect(404);

    expect(response.body).toHaveProperty('result');
    expect(response.body.result).toHaveProperty('success', false);
    expect(response.body.result).toHaveProperty('status', 404);
    expect(response.body.result.content).toHaveProperty('message');
  });
});
