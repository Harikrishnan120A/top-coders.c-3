"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
// Global test setup
beforeAll(async () => {
    // Connect to test database
    await prisma.$connect();
});
afterAll(async () => {
    // Clean up and disconnect
    await prisma.$disconnect();
});
// Make prisma available globally in tests
global.prisma = prisma;
//# sourceMappingURL=setup.js.map