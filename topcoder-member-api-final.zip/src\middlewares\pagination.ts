import { Request, Response, NextFunction } from 'express';

/**
 * Pagination middleware to standardize pagination parameters
 */
export interface PaginationParams {
  limit: number;
  offset: number;
  page: number;
}

export const paginationMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const defaultLimit = parseInt(process.env.DEFAULT_PAGE_SIZE || '20');
  const maxLimit = parseInt(process.env.MAX_PAGE_SIZE || '100');

  let limit = parseInt(req.query.limit as string) || defaultLimit;
  let offset = parseInt(req.query.offset as string) || 0;
  let page = parseInt(req.query.page as string) || 1;

  // Validate and constrain limits
  limit = Math.min(Math.max(limit, 1), maxLimit);
  offset = Math.max(offset, 0);
  page = Math.max(page, 1);

  // If page is provided, calculate offset
  if (req.query.page && !req.query.offset) {
    offset = (page - 1) * limit;
  }

  // Attach to request object
  req.pagination = {
    limit,
    offset,
    page: Math.floor(offset / limit) + 1
  };

  next();
};

// Extend Request interface
declare global {
  namespace Express {
    interface Request {
      pagination?: PaginationParams;
    }
  }
}
