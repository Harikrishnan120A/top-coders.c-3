/**
 * Basic tests that don't require database connection
 */

describe('Project Configuration', () => {
  it('should have correct TypeScript configuration', () => {
    const tsConfig = require('../tsconfig.json');
    expect(tsConfig.compilerOptions.target).toBe('ES2020');
    expect(tsConfig.compilerOptions.module).toBe('commonjs');
    expect(tsConfig.compilerOptions.strict).toBe(true);
  });

  it('should have correct package.json configuration', () => {
    const packageJson = require('../package.json');
    expect(packageJson.name).toBe('member-api');
    expect(packageJson.scripts.build).toBe('tsc');
    expect(packageJson.scripts.start).toBe('node dist/index.js');
    expect(packageJson.scripts.dev).toBe('nodemon src/index.ts');
  });

  it('should export utility functions', () => {
    const { createSuccessResponse } = require('../src/utils/response');
    const { validateRequired } = require('../src/utils/validation');
    
    expect(typeof createSuccessResponse).toBe('function');
    expect(typeof validateRequired).toBe('function');
  });

  it('should export middleware functions', () => {
    const { errorHandler } = require('../src/middlewares/errorHandler');
    const { paginationMiddleware } = require('../src/middlewares/pagination');
    
    expect(typeof errorHandler).toBe('function');
    expect(typeof paginationMiddleware).toBe('function');
  });
});

describe('Environment Configuration', () => {
  it('should load environment variables', () => {
    // In test environment, these should have defaults or be loaded from .env
    expect(process.env.NODE_ENV).toBeDefined();
    expect(process.env.DATABASE_URL).toBeDefined();
  });
});
