# Development Setup Guide

This guide will help you set up the Topcoder Member API for local development.

## Prerequisites

- Node.js 18+ and npm
- Docker and Docker Compose (recommended)
- Git

## Quick Start with Docker

1. **Clone and setup the project:**
```bash
git clone <repository-url>
cd member-api
npm install
```

2. **Start PostgreSQL with Docker:**
```bash
docker-compose up -d postgres
```

3. **Setup environment variables:**
```bash
cp .env.example .env
# Edit .env with your database connection details
```

4. **Run Prisma migrations:**
```bash
npm run prisma:migrate
npm run prisma:generate
```

5. **Seed the database with test data:**
```bash
npm run prisma:seed
```

6. **Start the development server:**
```bash
npm run dev
```

The API will be available at `http://localhost:3000`

## Manual PostgreSQL Setup

If you prefer not to use Docker:

1. **Install PostgreSQL:**
   - Windows: Download from [postgresql.org](https://www.postgresql.org/download/windows/)
   - macOS: `brew install postgresql`
   - Linux: `sudo apt-get install postgresql postgresql-contrib`

2. **Create database:**
```sql
createdb member_api
```

3. **Update .env file:**
```bash
DATABASE_URL="postgresql://username:password@localhost:5432/member_api?schema=public"
```

4. **Continue with steps 4-6 from Quick Start**

## Available Scripts

### Development
- `npm run dev` - Start development server with hot reload
- `npm run build` - Build TypeScript to JavaScript
- `npm start` - Start production server

### Database
- `npm run prisma:migrate` - Run database migrations
- `npm run prisma:generate` - Generate Prisma client
- `npm run prisma:studio` - Open Prisma Studio (database GUI)
- `npm run prisma:seed` - Seed database with test data

### Data Management
- `npm run data:fetch` - Fetch test data from live API
- `npm run prisma:seed` - Populate database with mock data

### Testing
- `npm test` - Run all tests
- `npm run test:watch` - Run tests in watch mode
- `npm run test:coverage` - Run tests with coverage report

### Code Quality
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Fix ESLint issues automatically
- `npm run format` - Format code with Prettier

## Database Management

### Using Prisma Studio
```bash
npm run prisma:studio
```
This opens a web-based database browser at `http://localhost:5555`

### Using pgAdmin (with Docker)
1. Start the full Docker stack: `docker-compose up -d`
2. Access pgAdmin at `http://localhost:8080`
3. Login with:
   - Email: `admin@example.com`
   - Password: `admin`
4. Add server connection:
   - Host: `postgres` (container name)
   - Port: `5432`
   - Database: `member_api`
   - Username: `postgres`
   - Password: `postgres`

## API Testing

### Health Check
```bash
curl http://localhost:3000/health
```

### Search Members
```bash
curl "http://localhost:3000/v5/members?limit=10&offset=0"
```

### Get Member by Handle
```bash
curl http://localhost:3000/v5/members/testuser
```

### Statistics Endpoints
```bash
curl http://localhost:3000/v5/members/statistics
curl http://localhost:3000/v5/members/statistics/skills
curl http://localhost:3000/v5/members/statistics/tracks
```

## Environment Variables

Key environment variables in `.env`:

- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Environment (development/production/test)
- `PORT` - Server port (default: 3000)
- `API_RATE_LIMIT` - Requests per minute limit
- `LOG_LEVEL` - Logging level (info/debug/error)

## Troubleshooting

### Database Connection Issues
1. Ensure PostgreSQL is running
2. Check DATABASE_URL in .env
3. Verify database exists: `psql -d member_api`

### Prisma Issues
1. Regenerate client: `npm run prisma:generate`
2. Reset database: `npx prisma migrate reset`
3. Check schema: `npx prisma validate`

### Test Failures
1. Ensure database is running for integration tests
2. Run basic tests only: `npx jest tests/basic.test.ts`
3. Check test setup in `tests/setup.ts`

### Port Already in Use
1. Kill process using port: `npx kill-port 3000`
2. Or change PORT in .env file

## Production Deployment

1. **Build the application:**
```bash
npm run build
```

2. **Set production environment variables:**
```bash
NODE_ENV=production
DATABASE_URL="your-production-database-url"
```

3. **Run migrations:**
```bash
npx prisma migrate deploy
```

4. **Start the server:**
```bash
npm start
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `npm test`
5. Run linting: `npm run lint`
6. Commit and push your changes
7. Create a pull request

## Support

For issues and questions:
1. Check this development guide
2. Review the main README.md
3. Check existing GitHub issues
4. Create a new issue with detailed information
