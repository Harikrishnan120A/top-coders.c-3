import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import memberRoutes from './routes/memberRoutes';
import { errorHandler } from './middlewares/errorHandler';

// Load environment variables
dotenv.config();

// Initialize Prisma Client
const prisma = new PrismaClient();

// Create Express app
const app = express();

// Middleware
app.use(helmet()); // Security headers
app.use(cors()); // Enable CORS
app.use(morgan('combined')); // HTTP request logging
app.use(express.json({ limit: '10mb' })); // Parse JSON bodies
app.use(express.urlencoded({ extended: true, limit: '10mb' })); // Parse URL-encoded bodies

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    message: 'Member API is running',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development'
  });
});

// API routes
app.use('/v5', memberRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Topcoder Member API v5',
    description: 'Migrated from Informix/ES/Dynamo to Prisma + PostgreSQL',
    version: '1.0.0',
    documentation: '/docs',
    endpoints: {
      health: '/health',
      members: '/v5/members',
      search: '/v5/members?query=...',
      memberByHandle: '/v5/members/:handle',
      statistics: '/v5/members/statistics',
      skillsStats: '/v5/members/statistics/skills',
      tracksStats: '/v5/members/statistics/tracks',
      countryStats: '/v5/members/statistics/countries',
      performanceStats: '/v5/members/statistics/performance'
    },
    queryParameters: {
      pagination: ['limit', 'offset', 'page'],
      search: ['query', 'handle', 'email', 'skills', 'tracks', 'country'],
      sorting: ['orderBy', 'sortOrder'],
      fields: ['fields']
    }
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    result: {
      success: false,
      status: 404,
      content: {
        message: `Route ${req.originalUrl} not found`,
        availableEndpoints: [
          'GET /health',
          'GET /v5/members',
          'GET /v5/members/:handle',
          'GET /v5/members/statistics',
          'GET /v5/members/statistics/skills',
          'GET /v5/members/statistics/tracks',
          'GET /v5/members/statistics/countries',
          'GET /v5/members/statistics/performance'
        ]
      }
    }
  });
});

// Error handler - must be last
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await prisma.$disconnect();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await prisma.$disconnect();
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start server
const server = app.listen(PORT, () => {
  console.log(`🚀 Member API server running on port ${PORT}`);
  console.log(`📚 Health check: http://localhost:${PORT}/health`);
  console.log(`🔗 API base: http://localhost:${PORT}/v5`);
  console.log(`📖 Documentation: http://localhost:${PORT}/`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});

export { app, prisma, server };
