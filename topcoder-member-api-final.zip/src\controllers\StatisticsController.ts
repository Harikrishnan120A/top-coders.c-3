import { Request, Response } from 'express';
import { PrismaClient, Prisma } from '@prisma/client';
import { createSuccessResponse, createErrorResponse } from '../utils/response';
import { sanitizeQuery } from '../utils/validation';

const prisma = new PrismaClient();

/**
 * StatisticsController - Handles member statistics operations
 * Migrated from Informix/ES/Dynamo to Prisma + PostgreSQL
 */
export class StatisticsController {

  /**
   * Get member statistics distribution
   * GET /v5/members/statistics
   */
  static async getMemberStatistics(req: Request, res: Response): Promise<void> {
    try {
      const {
        track,
        subTrack
      } = sanitizeQuery(req.query);

      // Build base where clause for active members
      const whereClause: Prisma.MemberWhereInput = {
        status: 'ACTIVE'
      };

      // Apply track filter if provided
      if (track) {
        whereClause.tracks = {
          some: {
            track: {
              name: { equals: track as string, mode: 'insensitive' }
            }
          }
        };
      }

      // Apply subtrack filter if provided
      if (subTrack) {
        whereClause.subTracks = {
          some: {
            subTrack: {
              name: { equals: subTrack as string, mode: 'insensitive' }
            }
          }
        };
      }

      // Get total member count
      const totalMembers = await prisma.member.count({ where: whereClause });

      // Get aggregations based on groupBy parameter
      const aggregations: Record<string, unknown> = {
        totalMembers
      };

      // Track distribution
      const trackStats = await prisma.member.findMany({
        where: whereClause,
        include: {
          tracks: {
            include: {
              track: true
            }
          }
        }
      });

      const trackCounts: Record<string, number> = {};
      trackStats.forEach(member => {
        member.tracks.forEach(memberTrack => {
          const trackName = memberTrack.track.name;
          trackCounts[trackName] = (trackCounts[trackName] || 0) + 1;
        });
      });

      aggregations.tracks = trackCounts;

      // Country distribution
      const countryStats = await prisma.member.groupBy({
        by: ['country'],
        where: whereClause,
        _count: {
          country: true
        },
        orderBy: {
          _count: {
            country: 'desc'
          }
        },
        take: 20
      });

      const countryCounts: Record<string, number> = {};
      countryStats.forEach(stat => {
        if (stat.country) {
          countryCounts[stat.country] = stat._count.country;
        }
      });

      aggregations.countries = countryCounts;

      // Member registration by year
      const memberSinceStats = await prisma.member.groupBy({
        by: ['memberSince'],
        where: whereClause,
        _count: {
          memberSince: true
        }
      });

      const yearCounts: Record<string, number> = {};
      memberSinceStats.forEach(stat => {
        if (stat.memberSince) {
          const year = stat.memberSince.getFullYear().toString();
          yearCounts[year] = (yearCounts[year] || 0) + stat._count.memberSince;
        }
      });

      aggregations.memberSince = yearCounts;

      // Last activity stats (approximate based on updatedAt)
      const now = new Date();
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const threeMonthsAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      const sixMonthsAgo = new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000);

      const [activeLastMonth, activeLastThreeMonths, activeLastSixMonths] = await Promise.all([
        prisma.member.count({
          where: {
            ...whereClause,
            updatedAt: { gte: oneMonthAgo }
          }
        }),
        prisma.member.count({
          where: {
            ...whereClause,
            updatedAt: { gte: threeMonthsAgo }
          }
        }),
        prisma.member.count({
          where: {
            ...whereClause,
            updatedAt: { gte: sixMonthsAgo }
          }
        })
      ]);

      aggregations.lastActivity = {
        lastMonth: activeLastMonth,
        lastThreeMonths: activeLastThreeMonths,
        lastSixMonths: activeLastSixMonths
      };

      const response = createSuccessResponse({ aggregations });
      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getMemberStatistics:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching statistics', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get skills distribution
   * GET /v5/members/statistics/skills
   */
  static async getSkillsStatistics(req: Request, res: Response): Promise<void> {
    try {
      const {
        track,
        limit = 50
      } = sanitizeQuery(req.query);

      const pageLimit = Math.min(parseInt(limit as string) || 50, 100);

      // Build where clause
      const whereClause: Prisma.MemberWhereInput = {
        status: 'ACTIVE'
      };

      if (track) {
        whereClause.tracks = {
          some: {
            track: {
              name: { equals: track as string, mode: 'insensitive' }
            }
          }
        };
      }

      // Get skills with member counts
      const skillsData = await prisma.skill.findMany({
        include: {
          members: {
            where: {
              member: whereClause
            }
          }
        },
        orderBy: {
          name: 'asc'
        }
      });

      // Calculate statistics
      const totalMembers = await prisma.member.count({ where: whereClause });
      
      const skills = skillsData
        .map(skill => ({
          id: skill.id,
          name: skill.name,
          category: skill.category,
          count: skill.members.length,
          percentage: totalMembers > 0 ? (skill.members.length / totalMembers) * 100 : 0
        }))
        .filter(skill => skill.count > 0)
        .sort((a, b) => b.count - a.count)
        .slice(0, pageLimit);

      const response = createSuccessResponse({
        skills,
        totalCount: skills.length,
        totalMembers
      });

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getSkillsStatistics:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching skills statistics', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get track/subtrack distribution
   * GET /v5/members/statistics/tracks
   */
  static async getTrackStatistics(req: Request, res: Response): Promise<void> {
    try {
      const whereClause: Prisma.MemberWhereInput = {
        status: 'ACTIVE'
      };

      // Get track statistics
      const tracksData = await prisma.track.findMany({
        include: {
          members: {
            where: {
              member: whereClause
            }
          }
        },
        orderBy: {
          name: 'asc'
        }
      });

      const totalMembers = await prisma.member.count({ where: whereClause });

      const tracks = tracksData.map(track => {
        const trackData: Record<string, unknown> = {
          id: track.id,
          name: track.name,
          description: track.description,
          count: track.members.length,
          percentage: totalMembers > 0 ? (track.members.length / totalMembers) * 100 : 0
        };

        return trackData;
      }).filter(track => (track.count as number) > 0);

      const response = createSuccessResponse({
        tracks,
        totalMembers
      });

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getTrackStatistics:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching track statistics', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get geographical distribution
   * GET /v5/members/statistics/countries
   */
  static async getCountryStatistics(req: Request, res: Response): Promise<void> {
    try {
      const { limit = 20 } = sanitizeQuery(req.query);

      const pageLimit = Math.min(parseInt(limit as string) || 20, 100);

      const whereClause: Prisma.MemberWhereInput = {
        status: 'ACTIVE',
        country: {
          not: null
        }
      };

      // Get country statistics
      const countryStats = await prisma.member.groupBy({
        by: ['country'],
        where: whereClause,
        _count: {
          country: true
        },
        orderBy: {
          _count: {
            country: 'desc'
          }
        },
        take: pageLimit
      });

      const totalMembers = await prisma.member.count({ where: whereClause });

      const countries = countryStats.map(stat => ({
        name: stat.country,
        count: stat._count.country,
        percentage: totalMembers > 0 ? (stat._count.country / totalMembers) * 100 : 0
      }));

      const response = createSuccessResponse({
        countries,
        totalMembers
      });

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getCountryStatistics:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching country statistics', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get performance statistics
   * GET /v5/members/statistics/performance
   */
  static async getPerformanceStatistics(req: Request, res: Response): Promise<void> {
    try {
      const { track, period = 'ALL_TIME' } = sanitizeQuery(req.query);

      const whereClause: Prisma.MemberStatisticWhereInput = {
        member: {
          status: 'ACTIVE'
        },
        period: period as string
      };

      if (track) {
        whereClause.member = {
          status: 'ACTIVE',
          tracks: {
            some: {
              track: {
                name: { equals: track as string, mode: 'insensitive' }
              }
            }
          }
        };
      }

      // Get rating statistics
      const ratingStats = await prisma.memberStatistic.aggregate({
        where: {
          ...whereClause,
          type: 'RATING'
        },
        _avg: { value: true },
        _min: { value: true },
        _max: { value: true },
        _count: { value: true }
      });

      // Get top performers
      const topPerformers = await prisma.memberStatistic.findMany({
        where: {
          ...whereClause,
          type: 'RATING'
        },
        include: {
          member: {
            select: {
              handle: true,
              firstName: true,
              lastName: true,
              country: true
            }
          }
        },
        orderBy: {
          value: 'desc'
        },
        take: 10
      });

      const response = createSuccessResponse({
        ratingStatistics: {
          average: ratingStats._avg.value || 0,
          minimum: ratingStats._min.value || 0,
          maximum: ratingStats._max.value || 0,
          count: ratingStats._count.value || 0
        },
        topPerformers: topPerformers.map(stat => ({
          handle: stat.member.handle,
          name: `${stat.member.firstName || ''} ${stat.member.lastName || ''}`.trim(),
          country: stat.member.country,
          rating: stat.value
        }))
      });

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getPerformanceStatistics:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching performance statistics', 500);
      res.status(500).json(errorResponse);
    }
  }
}
