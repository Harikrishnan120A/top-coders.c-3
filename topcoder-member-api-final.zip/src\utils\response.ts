/**
 * Utility functions for API responses
 */

export interface ApiResponse<T = unknown> {
  result: {
    success: boolean;
    status: number;
    metadata?: {
      totalCount?: number;
      limit?: number;
      offset?: number;
      page?: number;
    };
    content: T;
  };
}

/**
 * Create successful API response
 */
export const createSuccessResponse = <T>(
  data: T,
  metadata?: Record<string, unknown>
): ApiResponse<T> => {
  return {
    result: {
      success: true,
      status: 200,
      ...(metadata && { metadata }),
      content: data
    }
  };
};

/**
 * Create paginated response
 */
export const createPaginatedResponse = <T>(
  data: T[],
  totalCount: number,
  limit: number,
  offset: number
): ApiResponse<T[]> => {
  return {
    result: {
      success: true,
      status: 200,
      metadata: {
        totalCount,
        limit,
        offset,
        page: Math.floor(offset / limit) + 1
      },
      content: data
    }
  };
};

/**
 * Create error response
 */
export const createErrorResponse = (
  message: string,
  status: number = 500
): ApiResponse<{ message: string }> => {
  return {
    result: {
      success: false,
      status,
      content: {
        message
      }
    }
  };
};
