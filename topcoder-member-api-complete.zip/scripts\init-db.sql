-- Database initialization script
-- This script will run when the PostgreSQL container starts for the first time

-- Create additional schemas if needed
-- CREATE SCHEMA IF NOT EXISTS member_data;

-- Set timezone
SET timezone = 'UTC';

-- Create any initial database objects here if needed
-- Note: Prisma will handle table creation via migrations
