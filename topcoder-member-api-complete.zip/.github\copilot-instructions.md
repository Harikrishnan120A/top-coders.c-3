<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Topcoder Member API - Migration Project

This is a Node.js TypeScript project migrating the Topcoder Member API from a complex multi-database architecture (Informix, DynamoDB, ElasticSearch) to a simplified Prisma + PostgreSQL setup.

## Key Guidelines for Development

### Architecture Principles
- **Single Database**: Use only PostgreSQL with Prisma ORM
- **No Legacy Dependencies**: Remove all Informix, DynamoDB, ElasticSearch, DAL, and gRPC dependencies
- **Business Logic Preservation**: Maintain existing API behavior and business logic
- **Controllers in Scope**: Focus only on SearchController and StatisticsController

### Code Standards
- Use TypeScript with strict mode enabled
- Follow Express.js best practices for REST APIs
- Use Prisma Client for all database operations
- Implement proper error handling and validation
- Maintain API response format compatibility with existing endpoints

### Database Guidelines
- All models should use Prisma schema definitions
- Use proper relationships and constraints
- Include proper indexes for performance
- Support pagination, filtering, and sorting
- Use transactions where appropriate

### Testing Requirements
- Write unit tests for all business logic
- Use Jest for testing framework
- Include integration tests for API endpoints
- Maintain test coverage above 80%
- Use supertest for API testing

### API Compatibility
- Maintain response format matching https://api.topcoder-dev.com/v5/members
- Support all existing query parameters and filters
- Preserve pagination behavior
- Keep error response formats consistent

### Performance Considerations
- Optimize database queries using Prisma query optimization
- Implement proper indexing strategy
- Use efficient data loading patterns
- Consider caching strategies where appropriate

### Documentation
- Update README.md with setup and usage instructions
- Document API endpoints using OpenAPI/Swagger
- Include database schema documentation
- Provide clear migration and deployment instructions
