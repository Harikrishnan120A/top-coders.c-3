import { Request, Response } from 'express';
import { PrismaClient, Prisma } from '@prisma/client';
import { createSuccessResponse, createPaginatedResponse, createErrorResponse } from '../utils/response';
import { validateHandle, sanitizeQuery } from '../utils/validation';
import { MemberResponse } from '../types';

const prisma = new PrismaClient();

/**
 * SearchController - Handles member search operations
 * Migrated from Informix/ES/Dynamo to Prisma + PostgreSQL
 */
export class SearchController {
  
  /**
   * Search members with various filters
   * GET /v5/members
   */
  static async searchMembers(req: Request, res: Response): Promise<void> {
    try {
      const queryParams = sanitizeQuery(req.query);
      const {
        query,
        handle,
        email,
        skills,
        tracks,
        country,
        fields,
        limit = 20,
        offset = 0,
        orderBy = 'createdAt',
        sortOrder = 'desc'
      } = queryParams;

      const pageLimit = Math.min(Number(limit) || 20, 100);
      const pageOffset = Number(offset) || 0;

      // Build where clause
      const where: Prisma.MemberWhereInput = {
        status: 'ACTIVE'
      };

      // Text search across multiple fields
      if (query && typeof query === 'string') {
        where.OR = [
          { handle: { contains: query, mode: 'insensitive' } },
          { firstName: { contains: query, mode: 'insensitive' } },
          { lastName: { contains: query, mode: 'insensitive' } },
          { description: { contains: query, mode: 'insensitive' } }
        ];
      }

      // Exact handle match
      if (handle && typeof handle === 'string') {
        where.handle = { equals: handle, mode: 'insensitive' };
      }

      // Email search
      if (email && typeof email === 'string') {
        where.email = { contains: email, mode: 'insensitive' };
      }

      // Country filter
      if (country && typeof country === 'string') {
        where.country = { equals: country, mode: 'insensitive' };
      }

      // Skills filter
      if (skills) {
        const skillList = Array.isArray(skills) ? skills : [skills];
        where.skills = {
          some: {
            skill: {
              name: { in: skillList, mode: 'insensitive' }
            }
          }
        };
      }

      // Tracks filter
      if (tracks) {
        const trackList = Array.isArray(tracks) ? tracks : [tracks];
        where.tracks = {
          some: {
            track: {
              name: { in: trackList, mode: 'insensitive' }
            }
          }
        };
      }

      // Build orderBy clause
      const orderByClause: Prisma.MemberOrderByWithRelationInput = {};
      const validOrderFields = ['createdAt', 'updatedAt', 'memberSince', 'handle', 'firstName', 'lastName'];
      const orderField = validOrderFields.includes(orderBy as string) ? orderBy as string : 'createdAt';
      const sortDirection = sortOrder === 'asc' ? 'asc' : 'desc';
      
      orderByClause[orderField as keyof Prisma.MemberOrderByWithRelationInput] = sortDirection;

      // Build include clause based on fields
      const include = SearchController.buildIncludeClause(fields as string);

      // Execute queries
      const [members, totalCount] = await Promise.all([
        prisma.member.findMany({
          where,
          include,
          orderBy: orderByClause,
          take: pageLimit,
          skip: pageOffset
        }),
        prisma.member.count({ where })
      ]);

      // Transform response
      const transformedMembers = members.map(member => SearchController.transformMember(member));

      const response = createPaginatedResponse(
        transformedMembers,
        totalCount,
        pageLimit,
        pageOffset
      );

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in searchMembers:', error);
      const errorResponse = createErrorResponse('Internal server error while searching members', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get member by handle
   * GET /v5/members/:handle
   */
  static async getMemberByHandle(req: Request, res: Response): Promise<void> {
    try {
      const { handle } = req.params;
      const { fields } = req.query;

      if (!handle || !validateHandle(handle)) {
        const errorResponse = createErrorResponse('Invalid handle format', 400);
        res.status(400).json(errorResponse);
        return;
      }

      const include = SearchController.buildIncludeClause(fields as string);

      const member = await prisma.member.findFirst({
        where: {
          handle: { equals: handle, mode: 'insensitive' },
          status: 'ACTIVE'
        },
        include
      });

      if (!member) {
        const errorResponse = createErrorResponse(`Member with handle '${handle}' not found`, 404);
        res.status(404).json(errorResponse);
        return;
      }

      const transformedMember = SearchController.transformMember(member);
      const response = createSuccessResponse(transformedMember);

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getMemberByHandle:', error);
      const errorResponse = createErrorResponse('Internal server error while fetching member', 500);
      res.status(500).json(errorResponse);
    }
  }

  /**
   * Get members by IDs
   * GET /v5/members?userIds=1,2,3
   */
  static async getMembersByIds(req: Request, res: Response): Promise<void> {
    try {
      const { userIds, fields } = req.query;

      if (!userIds) {
        const errorResponse = createErrorResponse('userIds parameter is required', 400);
        res.status(400).json(errorResponse);
        return;
      }

      const ids = (userIds as string).split(',').map(id => {
        const parsedId = parseInt(id.trim());
        if (isNaN(parsedId)) {
          throw new Error(`Invalid user ID: ${id}`);
        }
        return parsedId;
      });

      const include = SearchController.buildIncludeClause(fields as string);

      const members = await prisma.member.findMany({
        where: {
          userId: { in: ids },
          status: 'ACTIVE'
        },
        include,
        orderBy: { handle: 'asc' }
      });

      const transformedMembers = members.map(member => 
        SearchController.transformMember(member)
      );

      const response = createSuccessResponse(transformedMembers);
      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getMembersByIds:', error);
      const errorResponse = createErrorResponse(
        error instanceof Error ? error.message : 'Internal server error while fetching members',
        400
      );
      res.status(400).json(errorResponse);
    }
  }

  /**
   * Build include clause based on requested fields
   */
  private static buildIncludeClause(fields?: string) {
    const defaultInclude = {
      tracks: {
        include: {
          track: true
        }
      },
      skills: {
        include: {
          skill: true
        },
        take: 10 // Limit skills to prevent large responses
      },
      achievements: {
        include: {
          achievement: true
        },
        take: 10
      },
      statistics: {
        take: 20
      }
    };

    if (!fields) return defaultInclude;

    const requestedFields = fields.split(',').map(f => f.trim().toLowerCase());
    const include: Record<string, unknown> = {};

    if (requestedFields.includes('tracks')) {
      include.tracks = defaultInclude.tracks;
    }

    if (requestedFields.includes('skills')) {
      include.skills = defaultInclude.skills;
    }

    if (requestedFields.includes('achievements')) {
      include.achievements = defaultInclude.achievements;
    }

    if (requestedFields.includes('statistics')) {
      include.statistics = defaultInclude.statistics;
    }

    // If no specific relations requested, include all
    if (Object.keys(include).length === 0) {
      return defaultInclude;
    }

    return include;
  }

  /**
   * Transform member data for API response
   */
  private static transformMember(member: Record<string, unknown>): MemberResponse {
    const result: MemberResponse = {
      userId: Number(member.userId),
      handle: String(member.handle),
      email: member.email ? String(member.email) : undefined,
      firstName: member.firstName ? String(member.firstName) : undefined,
      lastName: member.lastName ? String(member.lastName) : undefined,
      country: member.country ? String(member.country) : undefined,
      status: String(member.status),
      memberSince: member.memberSince ? member.memberSince as Date : undefined,
      lastLoginAt: member.lastLoginAt ? member.lastLoginAt as Date : undefined,
      isEmailVerified: Boolean(member.isEmailVerified),
      photoURL: member.photoURL ? String(member.photoURL) : undefined,
      createdAt: member.createdAt as Date,
      updatedAt: member.updatedAt as Date
    };

    // Add related data if included
    const tracks = member.tracks as Array<Record<string, unknown>>;
    if (tracks && tracks.length > 0) {
      result.tracks = tracks.map((memberTrack) => {
        const track = memberTrack.track as Record<string, unknown>;
        return {
          id: Number(track.id),
          name: String(track.name),
          description: track.description ? String(track.description) : undefined,
          isActive: Boolean(track.isActive)
        };
      });
    }

    const skills = member.skills as Array<Record<string, unknown>>;
    if (skills && skills.length > 0) {
      result.skills = skills.map((memberSkill) => {
        const skill = memberSkill.skill as Record<string, unknown>;
        return {
          id: Number(skill.id),
          name: String(skill.name),
          category: skill.category ? String(skill.category) : undefined,
          score: memberSkill.score ? Number(memberSkill.score) : null,
          achievedAt: memberSkill.achievedAt ? memberSkill.achievedAt as Date : null
        };
      });
    }

    const achievements = member.achievements as Array<Record<string, unknown>>;
    if (achievements && achievements.length > 0) {
      result.achievements = achievements.map((memberAchievement) => {
        const achievement = memberAchievement.achievement as Record<string, unknown>;
        return {
          id: Number(achievement.id),
          name: achievement.name ? String(achievement.name) : undefined,
          description: achievement.description ? String(achievement.description) : undefined,
          type: String(achievement.type),
          category: achievement.category ? String(achievement.category) : undefined,
          achievedAt: memberAchievement.achievedAt ? memberAchievement.achievedAt as Date : null
        };
      });
    }

    return result;
  }
}
