# Member API Documentation

This document describes the migrated Topcoder Member API endpoints.

## Base URL
```
http://localhost:3000/v5
```

## Authentication
Currently, no authentication is required for read operations.

## Response Format
All API responses follow this standard format:

```json
{
  "result": {
    "success": boolean,
    "status": number,
    "metadata": {
      "totalCount": number,     // For paginated responses
      "limit": number,          // For paginated responses  
      "offset": number,         // For paginated responses
      "page": number           // For paginated responses
    },
    "content": any             // The actual response data
  }
}
```

## Endpoints

### Health Check
Check if the API is running.

```
GET /health
```

**Response:**
```json
{
  "status": "OK",
  "timestamp": "2025-06-27T10:30:00.000Z",
  "message": "Member API is running"
}
```

### Search Members
Search for members with various filters.

```
GET /v5/members
```

**Query Parameters:**
- `query` (string) - Text search across member fields
- `handle` (string) - Exact handle match
- `email` (string) - Email search
- `skills` (string) - Comma-separated list of skills
- `tracks` (string) - Comma-separated list of tracks
- `country` (string) - Country filter
- `limit` (number) - Number of results (default: 20, max: 100)
- `offset` (number) - Pagination offset (default: 0)
- `page` (number) - Page number (alternative to offset)
- `orderBy` (string) - Sort field (default: createdAt)
- `sortOrder` (string) - Sort direction: asc/desc (default: desc)

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "metadata": {
      "totalCount": 150,
      "limit": 20,
      "offset": 0,
      "page": 1
    },
    "content": [
      {
        "userId": 1001,
        "handle": "testuser1",
        "email": "user@example.com",
        "firstName": "Test",
        "lastName": "User",
        "country": "United States",
        "memberSince": "2020-01-15T10:00:00.000Z",
        "tracks": ["DEVELOPMENT"],
        "skills": ["JavaScript", "React"],
        "photoURL": "https://example.com/photo.jpg"
      }
    ]
  }
}
```

### Get Member by Handle
Get detailed information about a specific member.

```
GET /v5/members/:handle
```

**Parameters:**
- `handle` (string) - Member handle

**Query Parameters:**
- `fields` (string) - Comma-separated list of fields to include

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "content": {
      "userId": 1001,
      "handle": "testuser1",
      "email": "user@example.com",
      "firstName": "Test",
      "lastName": "User",
      "description": "Software developer",
      "country": "United States",
      "memberSince": "2020-01-15T10:00:00.000Z",
      "lastLoginAt": "2025-06-27T09:00:00.000Z",
      "isEmailVerified": true,
      "photoURL": "https://example.com/photo.jpg",
      "tracks": [
        {
          "name": "DEVELOPMENT",
          "subTracks": [
            {
              "name": "ALGORITHM",
              "rating": 1500
            }
          ]
        }
      ],
      "skills": [
        {
          "name": "JavaScript",
          "score": 85
        }
      ],
      "achievements": [
        {
          "name": "First Place",
          "type": "BADGE",
          "achievedAt": "2023-01-15T10:00:00.000Z"
        }
      ],
      "statistics": {
        "rating": 1500,
        "wins": 5,
        "challenges": 25
      }
    }
  }
}
```

### Member Statistics
Get aggregated statistics about members.

```
GET /v5/members/statistics
```

**Query Parameters:**
- `track` (string) - Filter by track
- `subTrack` (string) - Filter by subtrack
- `groupBy` (string) - Group by field (track, country, etc.)

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "content": {
      "aggregations": {
        "totalMembers": 10000,
        "tracks": {
          "DEVELOPMENT": 6000,
          "DESIGN": 3000,
          "DATA_SCIENCE": 1000
        },
        "countries": {
          "United States": 3000,
          "India": 2000,
          "Ukraine": 1000
        },
        "memberSince": {
          "2023": 2000,
          "2022": 1500,
          "2021": 1200
        }
      }
    }
  }
}
```

### Skills Statistics
Get statistics about skill distribution.

```
GET /v5/members/statistics/skills
```

**Query Parameters:**
- `track` (string) - Filter by track
- `limit` (number) - Number of skills to return (default: 50)

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "content": {
      "skills": [
        {
          "name": "JavaScript",
          "count": 5000,
          "percentage": 50.0
        },
        {
          "name": "React",
          "count": 3000,
          "percentage": 30.0
        }
      ],
      "totalCount": 100
    }
  }
}
```

### Track Statistics
Get statistics about track/subtrack distribution.

```
GET /v5/members/statistics/tracks
```

**Query Parameters:**
- `includeSubTracks` (boolean) - Include subtrack breakdown

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "content": {
      "tracks": [
        {
          "name": "DEVELOPMENT",
          "count": 6000,
          "percentage": 60.0,
          "subTracks": [
            {
              "name": "ALGORITHM",
              "count": 3000
            }
          ]
        }
      ],
      "totalMembers": 10000
    }
  }
}
```

### Country Statistics
Get geographical distribution of members.

```
GET /v5/members/statistics/countries
```

**Query Parameters:**
- `limit` (number) - Number of countries to return (default: 20)

**Response:**
```json
{
  "result": {
    "success": true,
    "status": 200,
    "content": {
      "countries": [
        {
          "name": "United States",
          "count": 3000,
          "percentage": 30.0
        }
      ],
      "totalMembers": 10000
    }
  }
}
```

## Error Responses

All errors follow this format:

```json
{
  "result": {
    "success": false,
    "status": 404,
    "content": {
      "message": "Member with handle 'invalid' not found"
    }
  }
}
```

### Common Error Codes
- `400` - Bad Request (invalid parameters)
- `404` - Not Found (member/resource doesn't exist)
- `422` - Validation Error (invalid data format)
- `500` - Internal Server Error

## Migration Notes

This API maintains compatibility with the original Topcoder Member API while simplifying the backend architecture:

- **Before**: Informix + DynamoDB + ElasticSearch
- **After**: PostgreSQL + Prisma ORM

The response formats and query parameters remain the same to ensure backward compatibility.
