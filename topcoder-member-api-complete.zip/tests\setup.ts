import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Global test setup
beforeAll(async () => {
  // Try to connect to test database
  try {
    await prisma.$connect();
    console.log('✅ Connected to test database');
  } catch (error) {
    console.warn('⚠️ Could not connect to database. Some tests may be skipped.');
    console.warn('To run full tests, ensure PostgreSQL is running and DATABASE_URL is set.');
  }
});

afterAll(async () => {
  // Clean up and disconnect
  try {
    await prisma.$disconnect();
  } catch (error) {
    // Silent cleanup
  }
});

// Make prisma available globally in tests
(global as any).prisma = prisma;
