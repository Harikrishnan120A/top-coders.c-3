/**
 * TypeScript type definitions for the Member API
 */

import { Prisma } from '@prisma/client';

// Member types with relations
export type MemberWithRelations = Prisma.MemberGetPayload<{
  include: {
    tracks: {
      include: {
        track: true;
        subTrack: true;
      };
    };
    skills: {
      include: {
        skill: true;
      };
    };
    achievements: true;
  };
}>;

export interface MemberSearchQuery {
  query?: string;
  handle?: string;
  email?: string;
  skills?: string | string[];
  tracks?: string | string[];
  country?: string;
  limit?: number;
  offset?: number;
  orderBy?: 'handle' | 'createdAt' | 'rating';
  sortOrder?: 'asc' | 'desc';
  fields?: string;
}

export interface StatisticsQuery {
  track?: string;
  subTrack?: string;
  groupBy?: string;
  limit?: number;
}

export interface MemberResponse {
  userId: number;
  handle: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  country?: string;
  status: string;
  memberSince?: Date | null;
  lastLoginAt?: Date | null;
  isEmailVerified?: boolean;
  photoURL?: string | null;
  createdAt: Date;
  updatedAt: Date;
  tracks?: Array<{
    id: number;
    name: string;
    description?: string;
    isActive?: boolean;
  }>;
  skills?: Array<{
    id: number;
    name: string;
    category?: string;
    score?: number | null;
    achievedAt?: Date | null;
  }>;
  achievements?: Array<{
    id: number;
    name?: string;
    type: string;
    description?: string;
    category?: string;
    achievedAt?: Date | null;
  }>;
}

export interface SearchResponse {
  members: MemberResponse[];
  totalCount: number;
  limit: number;
  offset: number;
  page: number;
}

export interface StatisticsResponse {
  totalMembers: number;
  activeMembers: number;
  newMembersThisMonth: number;
  totalCountries: number;
  totalSkills: number;
  totalTracks: number;
}

export interface SkillStatistic {
  skill: string;
  count: number;
  percentage: number;
}

export interface TrackStatistic {
  track: string;
  count: number;
  percentage: number;
}

export interface CountryStatistic {
  country: string;
  count: number;
  percentage: number;
}
